$(document).ready(function () {
  startBxSlider();
  setHamburgerOnClick();
  wrapIframe();
  replaceImgWithSvg();
  setAlignInATag();
});

$(window).scroll(function () {
  setOnHeaderClass();
});

// functions
function wrapIframe(){
  $(".main-content iframe").wrap("<div class='embed-container'></div>");
}

function setOnHeaderClass(){
  var togglePosition = 10;
  var currentPosition = $(window).scrollTop();
  if (currentPosition > togglePosition) {
    $("header").addClass('scrolled');
    $("main").addClass('scrolled');
  } else {
    $("header").removeClass('scrolled');
    $("main").removeClass('scrolled');
  }
}

function startBxSlider(){
  $('.slider').bxSlider({
    auto: true,
    controls: false,
    pager: true,
    captions: true,
    mode: 'fade',
    pause: 3500,
    speed: 800
  });
}

function replaceImgWithSvg(){
  jQuery('img.svg').each(function () {
    var $img = jQuery(this);
    var imgID = $img.attr('id');
    var imgClass = $img.attr('class');
    var imgURL = $img.attr('src');
    jQuery.get(imgURL, function (data) {
      var $svg = jQuery(data).find('svg');
      if (typeof imgID !== 'undefined') {
        $svg = $svg.attr('id', imgID);
      }
      if (typeof imgClass !== 'undefined') {
        $svg = $svg.attr('class', imgClass + ' replaced-svg');
      }
      $svg = $svg.removeAttr('xmlns:a');
      if (!$svg.attr('viewBox') && $svg.attr('height') && $svg.attr('width')) {
        $svg.attr('viewBox', '0 0 ' + $svg.attr('height') + ' ' + $svg.attr('width'))
      }
      $img.replaceWith($svg);
  
    }, 'xml');
  
  });
}

function setHamburgerOnClick(){
  jQuery(".hamburger").each(function (i, e) {
    var hamburger = jQuery(e);
  
    hamburger.on("click", function () {
      $('#sidenav').toggleClass("is-active");
      $('html').toggleClass("is-active");
      $('.header-top').toggleClass("is-active");
    }, false);
  });
}

function setAlignInATag(){
  $('img[class*=align]').each(function(i, e){
    $(e).parents('a').addClass($(e).attr('class'));
  });
}

  
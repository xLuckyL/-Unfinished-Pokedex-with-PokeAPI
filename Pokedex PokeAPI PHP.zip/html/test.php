<?php

$base = "https://pokeapi.co/api/v2/pokemon/";
$id = 1;
$data = file_get_contents($base . $id . "/");
$pokemon = json_decode($data);


echo "<pre>";
var_dump($pokemon);
echo "</pre>";

?>

<?php
        // ophalen van de pokemons van de API
        $base = "https://pokeapi.co/api/v2/pokemon/";
        

        echo "<h1>Pokemon Pokedex</h1>";

        // Voor de pokemons te benoemen
        for ($id = 1; $id < 4; $id++) {
        $data = file_get_contents($base.$id.'/');
        $pokemon = json_decode($data);
        echo $pokemon->name."<br>";
        }

?>
<?php
$pokemon_api_url = "https://pokeapi.co/api/v2/pokemon/";
$pokemon_image_url = "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/%03d.png";

for ($id = 1; $id <= 20; $id++)
    $data = file_get_contents("{$pokemon_api_url}{$id}");
$pokemon = json_decode($data);
?>

<html>

<head>
    <title>Pokemon Information</title>
    <link rel="icon" type="image/x-icon" href="pokeball.png">

    <!-- Bootstrap core CSS -->
    <link href="stylesheets/bootstrap/bootstrap.css" rel="stylesheet">
    <link href="assets/fontawesome/css/all.css" rel="stylesheet" type="text/css" />
    <link href="/assets/owlcarousel/owl.carousel.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="sass/style.scss" rel="stylesheet">
    <!-- Let op dat je de SASS gebruikt, want hierin wordt het veranderd-->
</head>

<body>
    <h1>Pokemon Information</h1>

    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="pokemonInformatie">
                    <!--Foto van de pokemon-->
                    <div id="foto-pokemon-<?= $id; ?>" class="imageInformatie">
                        <img src="<?= sprintf($pokemon_image_url, $id); ?> ">
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <!--Tonen van Nummer pokemon-->
                <h3>Nummer Pokemon: <?= ($id); ?></h3>
                <!--Tonen van Naam pokemon-->
                <h3>Naam Pokemon: <?= ucfirst($pokemon->name); ?></h3><br>
                <!-- Tonen van Omschrijving Pokemon
                    <h3>Omschrijving pokemon: <?//= ucfirst($pokemon->sprites); ?></h3>-->

            </div>
        </div>
    </div>



    <!--Voor het werken van de simpele button-->
    <br>
    <form action="pokedexphp.php">
        <input type="submit" value="Ga terug " />
    </form>

</body>

</html>
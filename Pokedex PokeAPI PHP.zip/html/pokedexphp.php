<?php
$pokemon_api_url = "https://pokeapi.co/api/v2/pokemon/";
$pokemon_image_url = "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/%03d.png";
//De %03d betekend dat er 3 nummer wordt gebruikt
?>

<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="author" content="">

        <title>Pokemon Pokedex</title>
        <link rel="icon" type="image/x-icon" href="pokeball.png">

        <!-- Bootstrap core CSS -->
        <link href="stylesheets/bootstrap/bootstrap.css" rel="stylesheet">
        <link href="assets/fontawesome/css/all.css" rel="stylesheet" type="text/css" />
        <link href="/assets/owlcarousel/owl.carousel.min.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="sass/style.css" rel="stylesheet">
        <!-- Let op dat je de SASS/ gebruikt, want hierin wordt het veranderd-->
</head>


<body>
        <header>
                <div class="hamburger hamburger--squeeze">
                        <div class="hamburger-box">
                                <div class="hamburger-inner"></div>
                        </div>
                </div>
        </header>
        <main>
                <section class="pokemon-information">
                        <div class="container">
                                <h1>Pokemon Pokedex</h1>
                                <div class="row">
                                        <?php for ($id = 1; $id <= 20; $id++) :
                                                $data = file_get_contents("{$pokemon_api_url}{$id}");
                                                $pokemon = json_decode($data);
                                        ?>
                                                <div class="col-10 col-lg-3">
                                                        <a href="pokedetail.php?id=<?= $id; ?>" class="pokemon-item">
                                                                <!--Foto van de pokemon-->
                                                                <div id="foto-pokemon-<?= $id; ?>" class="image">
                                                                        <img src="<?= sprintf($pokemon_image_url, $id); ?> " alt="">
                                                                </div>
                                                        </a>
                                                        <div class="content">
                                                                <!--$id is voor het nummer en $pokemon->name is voor de pokemon naam te laten tonen-->
                                                                <h3>Nr.&nbsp<?= sprintf("%03d", $id); ?><br><br>
                                                                        <?= ucfirst($pokemon->name); ?>
                                                                </h3>
                                                                <!--Tonen van de types van de pokemon-->
                                                                <?php if (!empty($pokemon->types)) : ?>
                                                                        <div class="types">
                                                                                <?php foreach ($pokemon->types as $type) :  ?>
                                                                                        <label for="" class="<?= $type->type->name; ?>"><?= ucfirst($type->type->name); ?></label>

                                                                                <?php endforeach; ?>
                                                                        </div>
                                                                <?php endif; ?>
                                                        </div>
                                                </div>
                                        <?php endfor; ?>
                                </div>
                        </div>
                </section>
        </main>
        <footer>

        </footer>
        <script src="js/jQuery.js" type="text/javascript"></script>
        <script src="/assets/owlcarousel/owl.carousel.min.js" type="text/javascript"></script>
        <script src="js/main.js" type="text/javascript"></script>
</body>

</html>